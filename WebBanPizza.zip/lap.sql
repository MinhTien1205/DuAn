﻿ALTER DATABASE LapJava5 SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
use master
DROP DATABASE LapJava5;

create database LapJava5;
use LApJava5
go

CREATE TABLE Accounts (
    Username VARCHAR(50) PRIMARY KEY,
    Password VARCHAR(255) NOT NULL,
    Fullname VARCHAR(100),
    Email VARCHAR(100) UNIQUE,
    Photo VARCHAR(255),
    Activated BIT DEFAULT 1, -- TRUE = 1, FALSE = 0
    Admin BIT DEFAULT 0 -- Mặc định là người dùng thường, Admin = 1 nếu là quản trị viên
);
go
 
CREATE TABLE Categories (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    is_delete BIT DEFAULT 0 -- 1: đã xóa, 0: chưa xóa
);
go

CREATE TABLE Products (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Name VARCHAR(255) NOT NULL,
    Image VARCHAR(255),
    Price DECIMAL(10,2) NOT NULL,
    create_date DATETIME DEFAULT GETDATE(), -- Dùng GETDATE() thay cho CURRENT_TIMESTAMP
    Quantity INT NOT NULL,
    category_id INT,
    is_delete BIT DEFAULT 0, -- 1: đã xóa, 0: chưa xóa
    FOREIGN KEY (category_id) REFERENCES Categories(Id) ON DELETE SET NULL
);
go

CREATE TABLE Orders (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Username VARCHAR(50),
    create_date DATETIME DEFAULT GETDATE(),
    Address TEXT NOT NULL,
    total DECIMAL(10,2) NOT NULL,
    status VARCHAR(20) DEFAULT 'Pending', -- SQL Server không hỗ trợ ENUM, nên dùng VARCHAR
    FOREIGN KEY (Username) REFERENCES Accounts(Username) ON DELETE CASCADE
);
go

CREATE TABLE Order_Details (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    order_id INT,
    product_id INT,
    Price DECIMAL(10,2) NOT NULL,
    Quantity INT NOT NULL,
    FOREIGN KEY (order_id) REFERENCES Orders(Id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES Products(Id) ON DELETE CASCADE
);
go


INSERT INTO Categories (Name, is_delete) VALUES
(N'Pizza', 0),
(N'Khuyến mãi, Combo', 0),
(N'Khai vị', 0),
(N'Mỳ Ý', 0),
(N'Salad', 0),
(N'Đồ uống', 0);
go

INSERT INTO Accounts (Username, Password, Fullname, Email, Photo, Activated, Admin) VALUES
(N'minhtien', N'123', N'Đỗ Minh Tiến', N'dominhtien1205@gmail.com', N'hinhanh.jpg', 1, 1),
(N'tien', N'tien', N'tiến', N'dominhtien567@gmail.com', N'minhtien.jpg', 1, 0),
(N'admin', N'admin123', N'Quản Trị Viên', N'admin@thepizzacompany.com', N'admin.jpg', 1, 1),
(N'user1', N'user123', N'Trần Minh', N'user1@thepizzacompany.com', N'user1.jpg', 1, 0),
(N'user2', N'user123', N'Nguyễn Lan', N'user2@thepizzacompany.com', N'user2.jpg', 1, 0),
(N'user3', N'user123', N'Lê Hải', N'user3@thepizzacompany.com', N'user3.jpg', 1, 0);


INSERT INTO Products (Name, Image, Price, Quantity, category_id) VALUES
(N'Pizza Hải Sản Cao Cấp', N'hs2.png', 159000, 50, 1),
(N'Pizza Tôm Cocktail', N'pizza2.png', 159000, 60, 1),
(N'Pizza Hải Sản Cocktail', N'pizza3.png', 159000, 70, 1),
(N'Pizza Hải Sản Nhiệt Đới', N'pizza4.png', 159000, 40, 1),
(N'Mỳ Ý Cay Hải Sản', N'my1.png', 139000, 80, 2),
(N'Mỳ Ý Tôm Sốt Kem Cà Chua', N'my2.png', 139000, 30, 2),
(N'Mỳ Ý Thịt Bò Bằm', N'my3.png', 139000, 50, 2),
(N'Mỳ Ý Cay Xúc Xích', N'my4.png', 119000, 40, 2),
(N'Gà Giòn Xốt Hàn - Truyền Thống (9 miếng)', N'Khaivi3.png', 429000, 100, 3),
(N'Gà Giòn Xốt Tương Tỏi Hàn Quốc (2 miếng)', N'Khaivi4.png', 99000, 120, 3),
(N'Gà Nướng BBQ (5 miếng)', N'GaBBQ5M.jpeg', 219000, 60, 4),
(N'Salad Gà Giòn Không Xương', N'salad1.png', 89000, 80, 5),
(N'Salad Da Cá Hồi Giòn', N'salad2.png', 89000, 80, 5),
(N'Salad Đặc Sắc', N'salad3.png', 89000, 90, 5),
(N'Salad Trộn Sốt Caesar', N'salad4.png', 89000, 90, 5),
(N'Pepsi Black Lime Lon', N'nuoc1.png', 29000, 150, 6),
(N'Pepsi Black Lon', N'nuoc2.jpeg', 29000, 150, 6),
(N'Pepsi Lon', N'nuoc3.jpeg', 29000, 150, 6),
(N'Mirinda Soda Kem Lon', N'nuoc4.png', 29000, 150, 6);
go

INSERT INTO Orders (Username, Address, total, status) VALUES
(N'tien', N'262/26/78 Đường Lũy Bán Bích, Quận Tân Phú, TP.HCM', 278000, N'Completed'),
(N'tien', N'262/26/78 Đường Lũy Bán Bích, Quận Tân Phú, TP.HCM', 290000, N'Pending'),
(N'user1', N'159 Đường Điện Biên Phủ, Quận 3, TP.HCM', 198000, N'Completed'),
(N'user1', N'159 Đường Điện Biên Phủ, Quận 3, TP.HCM', 215000, N'Pending'),
(N'user2', N'753 Đường Hoàng Văn Thụ, Quận Phú Nhuận, TP.HCM', 189000, N'Completed'),
(N'user2', N'753 Đường Hoàng Văn Thụ, Quận Phú Nhuận, TP.HCM', 155000, N'Pending'),
(N'user3', N'852 Đường Trần Hưng Đạo, Quận 5, TP.HCM', 96000, N'Completed'),
(N'user3', N'852 Đường Trần Hưng Đạo, Quận 5, TP.HCM', 120000, N'Pending');
GO

INSERT INTO Order_Details (order_id, product_id, Price, Quantity) VALUES
(1, 1, 159000, 1),  -- Pizza Hải Sản Cao Cấp
(1, 5, 119000, 1),  -- Mỳ Ý Cay Hải Sản

(2, 2, 159000, 1),  -- Pizza Tôm Cocktail
(2, 17, 29000, 1),  -- Pepsi Black Lime Lon
(2, 18, 29000, 1),  -- Pepsi Black Lon

(3, 3, 159000, 1),  -- Pizza Hải Sản Cocktail
(3, 9, 429000, 1),  -- Gà Giòn Xốt Hàn (9 miếng)

(4, 4, 159000, 1),  -- Pizza Hải Sản Nhiệt Đới
(4, 19, 29000, 2),  -- Pepsi Lon

(5, 6, 139000, 1),  -- Mỳ Ý Tôm Sốt Kem Cà Chua
(5, 10, 99000, 1),  -- Gà Giòn Xốt Tương Tỏi Hàn Quốc (2 miếng)

(6, 7, 139000, 1),  -- Mỳ Ý Thịt Bò Bằm
(6, 12, 89000, 1),  -- Salad Gà Giòn Không Xương
(6, 19, 29000, 1),  -- Mirinda Soda Kem Lon

(7, 8, 119000, 1),  -- Mỳ Ý Cay Xúc Xích
(7, 14, 89000, 1),  -- Salad Đặc Sắc

(8, 11, 219000, 1), -- Gà Nướng BBQ (5 miếng)
(8, 16, 29000, 1),  -- Pepsi Black Lime Lon
(8, 18, 29000, 1),  -- Pepsi Black Lon
(8, 19, 29000, 1);  -- Pepsi Lon


