import guiUtils.RequestLogBuffer;
import guiUtils.ServerStatusListener;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ServerDashboard extends JFrame {
    private JLabel statusLabel;
    private JButton startButton;
    private JButton stopButton;
    private JTextArea logArea;
    private JLabel uptimeLabel;
    private Timer uptimeTimer;
    private long startTime;
    private boolean isServerRunning = false;
    private ServerStatusListener statusListener;  // Lắng nghe sự thay đổi trạng thái server

    public ServerDashboard(RequestLogBuffer logBuffer, ServerStatusListener statusListener) {
        this.statusListener = statusListener;
        logBuffer.registerListener(this::logMessage); // Khi có log mới → gọi logMessage

        // Basic frame setup
        setTitle("Web Server Dashboard");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Create main panel with padding
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Top panel for status and controls
        JPanel topPanel = new JPanel(new BorderLayout(10, 10));

        // Status panel
        JPanel statusPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        statusLabel = new JLabel("Server Status: STOPPED");
        statusLabel.setFont(new Font("Arial", Font.BOLD, 14));
        statusPanel.add(statusLabel);

        // Control panel
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        startButton = new JButton("Start Server");
        stopButton = new JButton("Stop Server");
        stopButton.setEnabled(false);

        controlPanel.add(startButton);
        controlPanel.add(stopButton);

        topPanel.add(statusPanel, BorderLayout.WEST);
        topPanel.add(controlPanel, BorderLayout.EAST);

        // Center panel for logs
        JPanel centerPanel = new JPanel(new BorderLayout(10, 10));
        logArea = new JTextArea();
        logArea.setEditable(false);
        logArea.setFont(new Font("Monospace", Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(logArea);
        centerPanel.add(new JLabel("Server Logs:"), BorderLayout.NORTH);
        centerPanel.add(scrollPane, BorderLayout.CENTER);

        // Bottom panel for statistics
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        uptimeLabel = new JLabel("Uptime: 00:00:00");
        bottomPanel.add(uptimeLabel);

        // Add all panels to main panel
        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(centerPanel, BorderLayout.CENTER);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        // Add main panel to frame
        add(mainPanel);

        // Initialize timer for uptime
        uptimeTimer = new Timer(1000, e -> updateUptime());

        // Add button listeners
        startButton.addActionListener(e -> startServer());
        stopButton.addActionListener(e -> stopServer());

    }

    private void startServer() {
        isServerRunning = true;
        statusLabel.setText("Server Status: RUNNING");
        statusLabel.setForeground(Color.GREEN);
        startButton.setEnabled(false);
        stopButton.setEnabled(true);

        startTime = System.currentTimeMillis();
        uptimeTimer.start();

        logMessage("Server started on port 8080");
        statusListener.onServerStatusChanged(true);
    }

    private void stopServer() {
        isServerRunning = false;
        statusLabel.setText("Server Status: STOPPED");
        statusLabel.setForeground(Color.BLACK);
        startButton.setEnabled(true);
        stopButton.setEnabled(false);

        uptimeTimer.stop();
        uptimeLabel.setText("Uptime: 00:00:00");

        logMessage("Server stopped");
        statusListener.onServerStatusChanged(false);
    }

    private void updateUptime() {
        long uptime = System.currentTimeMillis() - startTime;
        long seconds = (uptime / 1000) % 60;
        long minutes = (uptime / (1000 * 60)) % 60;
        long hours = (uptime / (1000 * 60 * 60)) % 24;

        uptimeLabel.setText(String.format("Uptime: %02d:%02d:%02d", hours, minutes, seconds));
    }

    private void logMessage(String message) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String timestamp = sdf.format(new Date());
        logArea.append(String.format("[%s] %s%n", timestamp, message));
        logArea.setCaretPosition(logArea.getDocument().getLength());
    }
}
