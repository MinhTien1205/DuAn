import guiUtils.RequestLogBuffer;
import guiUtils.ServerStatusListener;
import org.asmproject.AsmProjectApplication;
import org.springframework.boot.SpringApplication;

import javax.swing.*;

public class MainApp {

    public static void main(String[] args) {

        // Khởi tạo RequestLogBuffer và ServerStatusListener
        RequestLogBuffer logBuffer = new RequestLogBuffer();
        ServerStatusListener statusListener = new ServerStatusListener() {
            @Override
            public void onServerStatusChanged(boolean isRunning) {
                SwingUtilities.invokeLater(() -> {
                    // Cập nhật GUI khi trạng thái server thay đổi
                    System.out.println("Server status changed: " + (isRunning ? "Running" : "Stopped"));
                });
            }
        };

        // 1. Khởi chạy Spring Boot trong một thread riêng
        Thread serverThread = new Thread(() -> {
            try {
                System.out.println("Spring Boot server is starting...");
                SpringApplication.run(AsmProjectApplication.class, args);
                // Sau khi server khởi động thành công, thông báo GUI
                statusListener.onServerStatusChanged(true);
            } catch (Exception e) {
                e.printStackTrace();
                statusListener.onServerStatusChanged(false);
            }
        });
        serverThread.setDaemon(false);  // Đảm bảo thread này không dừng khi main thread dừng
        serverThread.start();

        // 2. Tạo và hiển thị GUI (Swing)
        SwingUtilities.invokeLater(() -> {
            try {
                System.out.println("Launching Server Dashboard GUI...");
                ServerDashboard dashboard = new ServerDashboard(logBuffer, statusListener); // Truyền listener vào constructor của GUI
                dashboard.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
