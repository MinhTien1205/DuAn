package guiUtils;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component
public class RequestLoggerFilter extends OncePerRequestFilter {

    @Autowired
    private RequestLogBuffer logBuffer; // service trung gian để gửi log

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {
        String method = request.getMethod();
        String uri = request.getRequestURI();

        String log = String.format("[%s] %s", method, uri);
        logBuffer.addLog(log); // gửi log tới GUI

        filterChain.doFilter(request, response); // tiếp tục chuỗi filter
    }
}
