package guiUtils;

public interface ServerStatusListener {
    // Phương thức này sẽ được gọi khi trạng thái server thay đổi
    void onServerStatusChanged(boolean isRunning);
}

