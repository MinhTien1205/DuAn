package guiUtils;

import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

@Component
public class RequestLogBuffer {
    private final List<Consumer<String>> listeners = new ArrayList<>();

    public void addLog(String log) {
        for (Consumer<String> listener : listeners) {
            listener.accept(log);
        }
    }

    public void registerListener(Consumer<String> listener) {
        listeners.add(listener);
    }
}

