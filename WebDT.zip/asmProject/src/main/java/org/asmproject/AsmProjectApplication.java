package org.asmproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AsmProjectApplication {
    public static void main(String[] args) {
        SpringApplication.run(AsmProjectApplication.class, args);
    }
}
