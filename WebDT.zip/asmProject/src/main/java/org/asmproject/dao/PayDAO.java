package org.asmproject.dao;

import com.fasterxml.jackson.databind.JsonNode;
import org.asmproject.bean.Pay;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Repository
public class PayDAO {
    private final RestTemplate rest;
    private final String url = "https://poly-java-6-7593b-default-rtdb.firebaseio.com/payRequests.json";

    public PayDAO() {
        this.rest = new RestTemplate();
    }

    private String getUrl(String key) {
        return url.replace(".json", "/" + key + ".json");
    }

    public Map<String, Pay> findAllMap() {
        ResponseEntity<Map<String, Pay>> response = rest.exchange(
                url, HttpMethod.GET, null, new ParameterizedTypeReference<Map<String, Pay>>() {}
        );
        return response.getBody();
    }
    public Pay updatePayment(String orderId, String status) {
        // Get the current payment from the database
        Pay pay = getPaymentById(orderId);

        if (pay != null) {
            pay.setStatus(status);  // Set the new status

            // Send the updated payment data to Firebase
            HttpEntity<Pay> entity = new HttpEntity<>(pay);
            rest.put(getUrl(orderId), entity);  // Firebase PUT request to update the status

            return pay;  // Return the updated payment object
        } else {
            // If the payment is not found, return null or throw an exception
            return null;
        }
    }


    public List<Pay> getAllPaymentsWithKey() {
        try {
            return findAllMap().entrySet().stream()
                    .map(entry -> {
                        Pay pay = entry.getValue();
                        pay.setId(entry.getKey());
                        return pay;
                    })
                    .collect(Collectors.toList());
        } catch (Exception e) {
            // Log and handle the exception
            throw new RuntimeException("Error fetching payments from Firebase", e);
        }
    }


    public String create(Pay payEntity) {
        HttpEntity<Pay> entity = new HttpEntity<>(payEntity);
        ResponseEntity<JsonNode> response = rest.exchange(url, HttpMethod.POST, entity, JsonNode.class);
        JsonNode resp = response.getBody();
        return resp != null ? resp.get("name").asText() : null; // Firebase auto-generated key
    }


    public Pay update(String key, Pay payEntity) {
        HttpEntity<Pay> entity = new HttpEntity<>(payEntity);
        rest.put(getUrl(key), entity);
        return payEntity;
    }

    public void delete(String key) {
        rest.delete(getUrl(key));
    }

    public Pay getPaymentById(String id) {
        String fullUrl = getUrl(id);
        ResponseEntity<Pay> response = rest.getForEntity(fullUrl, Pay.class);
        Pay pay = response.getBody();
        if (pay != null) {
            pay.setId(id);
        } else {
            // Handle the case where the pay object is not found
            throw new RuntimeException("Payment not found for id: " + id);
        }
        return pay;
    }


}
