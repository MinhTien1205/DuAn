package org.asmproject.dao;

import com.fasterxml.jackson.databind.JsonNode;
import org.asmproject.bean.User;
import org.asmproject.bean.UserMap;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;

@Repository
public class UserDAO {
    private final RestTemplate rest = new RestTemplate();

    private static final String BASE_URL = "https://poly-java-6-7593b-default-rtdb.firebaseio.com/user";
    private static final String FULL_URL = BASE_URL + ".json";

    private String getUrl(String key) {
        return BASE_URL + "/" + key + ".json";
    }

    public UserMap findAll() {
        return rest.getForObject(FULL_URL, UserMap.class);
    }

    public User findByKey(String key) {
        return rest.getForObject(getUrl(key), User.class);
    }

    public String findKeyByUsername(String username) {
        UserMap userMap = rest.getForObject(FULL_URL, UserMap.class);
        if (userMap != null) {
            for (String key : userMap.keySet()) {
                User user = userMap.get(key);
                if (user.getUsername() != null && user.getUsername().equalsIgnoreCase(username)) {
                    return key;
                }
            }
        }
        return null;
    }


    public User findByUsername(String username) {
        UserMap userMap = rest.getForObject(FULL_URL, UserMap.class);

        if (userMap != null) {
            for (User user : userMap.values()) {
                if (user.getUsername() != null && user.getUsername().equalsIgnoreCase(username)) {
                    System.out.println("Finding: " + username + " | " + user.getUsername());
                    return user;
                }
            }
        }
        return null;
    }

    public String create(User data) {
        HttpEntity<User> entity = new HttpEntity<>(data);
        JsonNode resp = rest.postForObject(FULL_URL, entity, JsonNode.class);
        return resp.get("name").asText(); // Firebase trả về {"name": "-Nxyz123..."}
    }

    public User update(String key, User data) {
        HttpEntity<User> entity = new HttpEntity<>(data);
        rest.put(getUrl(key), entity);
        return data;
    }

    public void delete(String key) {
        rest.delete(getUrl(key));
    }
}
