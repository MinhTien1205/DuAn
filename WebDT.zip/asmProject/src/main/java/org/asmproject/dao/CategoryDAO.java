package org.asmproject.dao;

import org.asmproject.bean.CategoryMap;
import org.asmproject.bean.Category;
import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;

@Repository
public class CategoryDAO {
    RestTemplate rest = new RestTemplate();

    // URL của Firebase Realtime Database cho Category
    String url = "https://poly-java-6-7593b-default-rtdb.firebaseio.com/Category.json";

    private String getUrl(String key) {
        return url.replace(".json", "/" + key + ".json");
    }

    // Lấy tất cả danh sách Category từ Firebase
    public CategoryMap findAll(){
        return rest.getForObject(url, CategoryMap.class);
    }

    // Lấy Category theo key
    public Category findByKey(String key){
        return rest.getForObject(getUrl(key), Category.class);
    }

    // Tạo mới Category
    public String create(Category data){
        HttpEntity<Category> entity = new HttpEntity<>(data);
        JsonNode resp = rest.postForObject(url, entity, JsonNode.class);
        return resp.get("name").asText(); // Lấy tên của Category mới
    }

    // Cập nhật Category
    public Category update(String key, Category data){
        HttpEntity<Category> entity = new HttpEntity<>(data);
        rest.put(getUrl(key), entity);
        return data;
    }

    // Xóa Category
    public void delete(String key){
        rest.delete(getUrl(key));
    }
}
