package org.asmproject.dao;

import com.fasterxml.jackson.databind.JsonNode;
import org.asmproject.bean.Product;
import org.asmproject.bean.ProductMap;
import org.asmproject.bean.ProductPage;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Repository
public class ProductDAO {
    RestTemplate rest = new RestTemplate();

    String url = "https://poly-java-6-7593b-default-rtdb.firebaseio.com/product.json";



    private String getUrl(String key) {
        return url.replace(".json", "/" + key + ".json");
    }

    public ProductMap findAll() {
        return rest.getForObject(url, ProductMap.class);
    }

    public Product findByKey(String key) {
        return rest.getForObject(getUrl(key), Product.class);
    }

    public Product findById(String id) {
        ResponseEntity<Product> response = rest.exchange(
                getUrl(id), HttpMethod.GET, null, Product.class
        );
        return response.getBody();
    }

    public Map<String, Product> findAllMap() {
        ResponseEntity<Map<String, Product>> response = rest.exchange(
                url, HttpMethod.GET, null, new ParameterizedTypeReference<>() {}
        );
        return response.getBody();
    }

    public List<Product> getAllProductsWithKey() {
        return findAllMap().entrySet().stream()
                .map(entry -> {
                    Product product = entry.getValue();
                    product.setId(entry.getKey()); // set lại ID từ key Firebase
                    return product;
                })
                .collect(Collectors.toList());
    }

    public String create(Product data) {
        HttpEntity<Product> entity = new HttpEntity<>(data);
        JsonNode resp = rest.postForObject(url, entity, JsonNode.class);
        return resp.get("name").asText();
    }

    public Product update(String key, Product data) {
        HttpEntity<Product> entity = new HttpEntity<>(data);
        rest.put(getUrl(key), entity);
        return data;
    }


    public void delete(String key) {
        rest.delete(getUrl(key));
    }

    public ProductPage getPagedProducts(int page, int pageSize) {
        List<Product> allProducts = getAllProductsWithKey(); // dùng method mới

        int totalPages = (int) Math.ceil((double) allProducts.size() / pageSize);
        int start = page * pageSize;
        int end = Math.min(start + pageSize, allProducts.size());

        if (start > end) start = end;

        List<Product> pagedProducts = allProducts.subList(start, end);
        return new ProductPage(pagedProducts, totalPages);
    }


}
