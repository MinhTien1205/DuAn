package org.asmproject.dao;

import org.asmproject.bean.Cart;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;
import com.fasterxml.jackson.databind.JsonNode;

import java.util.*;

@Repository
public class CartDAO {


    private final RestTemplate restTemplate = new RestTemplate();
    private final String url = "https://poly-java-6-7593b-default-rtdb.firebaseio.com/cart.json";

    // URL cho giỏ hàng của người dùng
    private String getUserCartUrl(String username) {
        return "https://poly-java-6-7593b-default-rtdb.firebaseio.com/cart/" + username + ".json";
    }

    // Thêm sản phẩm vào giỏ hàng
    public void addToCart(String username, Cart cart) {
        // Bước 1: Lấy giỏ hàng hiện tại của người dùng
        List<Cart> existingCartItems = getCartByUsername(username);

        // Bước 2: Kiểm tra xem sản phẩm đã tồn tại trong giỏ chưa
        for (Cart existing : existingCartItems) {
            if (existing.getProductId().equals(cart.getProductId())) {
                // Nếu đã có, cập nhật số lượng
                existing.setQuantity(existing.getQuantity() + cart.getQuantity());
                updateCart(existing); // Gọi hàm updateCart để cập nhật trên Firebase
                System.out.println("📝 Sản phẩm đã tồn tại, cập nhật số lượng.");
                return;
            }
        }

        // Bước 3: Nếu sản phẩm chưa tồn tại, thêm mới
        String cartUrl = getUserCartUrl(username);  // Lấy URL giỏ hàng của người dùng

        // Gửi đối tượng Cart trực tiếp vào Firebase
        ResponseEntity<JsonNode> response = restTemplate.postForEntity(cartUrl, cart, JsonNode.class);
        JsonNode responseBody = response.getBody();

        // Kiểm tra phản hồi từ Firebase và xử lý ID sản phẩm
        if (responseBody != null && responseBody.has("name")) {
            String generatedId = responseBody.get("name").asText();  // Firebase trả về ID của mục mới
            cart.setId(generatedId);  // Gán ID cho Cart
            System.out.println("✅ Thêm mới sản phẩm vào giỏ với ID: " + generatedId);
        } else {
            System.err.println("❌ Lỗi khi thêm sản phẩm mới vào giỏ: " + responseBody);
        }
    }





    // Lấy giỏ hàng của người dùng
    public List<Cart> getCartByUsername(String username) {
        String url = "https://poly-java-6-7593b-default-rtdb.firebaseio.com/cart/" + username + ".json";

        ResponseEntity<Map<String, Cart>> response = restTemplate.exchange(
                url, HttpMethod.GET, null, new ParameterizedTypeReference<>() {}
        );

        Map<String, Cart> map = response.getBody();
        List<Cart> result = new ArrayList<>();
        if (map != null) {
            for (Map.Entry<String, Cart> entry : map.entrySet()) {
                Cart item = entry.getValue();
                item.setId(entry.getKey());
                result.add(item);
            }
        }
        return result;
    }




    // Xóa sản phẩm khỏi giỏ hàng
    public void removeFromCart(String username, String productId, String cartId) {
        String cartUrl = getUserCartUrl(username);  // Get the user's cart base URL
        if (cartId == null) {
            System.err.println("Error: Cart item ID is null");
            return;  // If cartId is null, don't proceed with deletion
        }

        String deleteUrl = "https://poly-java-6-7593b-default-rtdb.firebaseio.com/cart/" + username + "/" + cartId + ".json";


        try {
            restTemplate.delete(deleteUrl);  // Send DELETE request to Firebase
        } catch (Exception e) {
            System.err.println("Error deleting product from cart: " + e.getMessage());
        }
    }

    // Tìm một Cart item theo productId
    public Cart getCartItem(String username, String productId) {
        String url = "https://poly-java-6-7593b-default-rtdb.firebaseio.com/cart/" + username + ".json";

        ResponseEntity<Map<String, Cart>> response = restTemplate.exchange(
                url, HttpMethod.GET, null, new ParameterizedTypeReference<>() {}
        );

        Map<String, Cart> map = response.getBody();
        if (map != null) {
            for (Map.Entry<String, Cart> entry : map.entrySet()) {
                Cart item = entry.getValue();
                if (productId.equals(item.getProductId())) {
                    item.setId(entry.getKey()); // Gán ID từ Firebase
                    return item;
                }
            }
        }

        return null; // Không tìm thấy
    }


    // Cập nhật số lượng hoặc dữ liệu Cart trong Firebase
    public void updateCart(Cart cart) {
        if (cart.getId() == null || cart.getId().isEmpty()) {
            System.err.println("❌ Không có ID cart để cập nhật.");
            return;
        }

        String updateUrl = "https://poly-java-6-7593b-default-rtdb.firebaseio.com/cart/"
                + cart.getUsername() + "/" + cart.getId() + ".json";

        try {
            restTemplate.put(updateUrl, cart); // ✅ PUT sẽ ghi đè dữ liệu
            System.out.println("✅ Cập nhật cart thành công cho ID: " + cart.getId());
        } catch (Exception e) {
            System.err.println("❌ Lỗi khi cập nhật cart: " + e.getMessage());
        }
    }



}
