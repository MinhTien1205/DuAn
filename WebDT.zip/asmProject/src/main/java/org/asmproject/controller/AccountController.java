package org.asmproject.controller;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.asmproject.bean.User;
import org.asmproject.dao.UserDAO;
import org.asmproject.security.AuthRequest;
import org.asmproject.security.JwtUtil;
import org.asmproject.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
@Controller
@RequestMapping("/account")
public class AccountController {

    @Autowired
    private UserService userService;

    @Autowired
    private UserDAO userDAO;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtUtil jwtUtil;

    // Kiểm tra JWT trong cookie
    private boolean isUserAuthenticated(HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if ("jwtToken".equals(cookie.getName())) {
                    return true;  // Người dùng đã đăng nhập (có token)
                }
            }
        }
        return false;  // Người dùng chưa đăng nhập
    }

    @GetMapping("/login")
    public String loginPage(HttpServletRequest request, Model model) {
        // Kiểm tra nếu người dùng đã đăng nhập, chuyển hướng về trang chủ
        if (isUserAuthenticated(request)) {
            return "redirect:/";  // Đã đăng nhập, chuyển hướng về trang chủ
        }

        model.addAttribute("user", new User());
        model.addAttribute("page", "/account/login");
        return "layout";
    }

    @GetMapping("/register")
    public String registerPage(HttpServletRequest request, Model model) {
        // Kiểm tra nếu người dùng đã đăng nhập, chuyển hướng về trang chủ
        if (isUserAuthenticated(request)) {
            return "redirect:/";  // Đã đăng nhập, chuyển hướng về trang chủ
        }

        model.addAttribute("user", new User());
        model.addAttribute("page", "/account/register");
        return "layout";
    }

    @PostMapping("/register")
    public String registerUser(User user, Model model) {
        if (userService.isUserExists(user.getUsername())) {
            model.addAttribute("error", "Username already exists");
            model.addAttribute("user", new User());
            model.addAttribute("page", "/account/register");
            return "layout";
        } else {
            // Mã hóa mật khẩu trước khi lưu
            user.setPassword(passwordEncoder.encode(user.getPassword()));
            userService.createUser(user);
            return "redirect:/account/login";
        }
    }

    @GetMapping("/info")
    public String showInfo(Model model, @CookieValue("username") String username) {
        User user = userDAO.findByUsername(username);
        model.addAttribute("user", user);
        model.addAttribute("page", "/account/info");
        return "layout";
    }

    @PostMapping("/update")
    public String updateInfo(@CookieValue("username") String username,
                             @RequestParam String fullname,
                             @RequestParam String email,
                             @RequestParam String phone,
                             @RequestParam String address) {
        User user = userDAO.findByUsername(username);
        user.setFullname(fullname);
        user.setEmail(email);
        user.setPhone(phone);
        user.setAddress(address);
        String key = userDAO.findKeyByUsername(username);
        if (key != null) {
            userDAO.update(key, user);
        }
        return "redirect:/account/info";
    }




    @GetMapping("/logout")
    public String logout(HttpServletRequest request, HttpServletResponse response) {
        // Xóa cookie JWT
        System.out.println("logout!");
        Cookie cookie = new Cookie("jwtToken", null);
        cookie.setHttpOnly(false);
        cookie.setSecure(false); // 🔥 DÙNG false nếu đang localhost
        cookie.setPath("/");
        cookie.setMaxAge(0); // Xóa cookie ngay lập tức
        response.addCookie(cookie);
        Cookie cookie1 = new Cookie("username", null);
        cookie1.setHttpOnly(false);
        cookie1.setSecure(false); // 🔥 DÙNG false nếu đang localhost
        cookie1.setPath("/");
        cookie1.setMaxAge(0); // Xóa cookie ngay lập tức
        response.addCookie(cookie1);

        return "redirect:/";
    }


}
