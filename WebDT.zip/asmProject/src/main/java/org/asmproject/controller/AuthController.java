package org.asmproject.controller;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.asmproject.bean.User;
import org.asmproject.dao.UserDAO;
import org.asmproject.security.AuthRequest;
import org.asmproject.security.AuthResponse;
import org.asmproject.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AuthController {
    private final UserDAO userDAO;
    private final JwtUtil jwtUtil;
    private final PasswordEncoder passwordEncoder;
    public AuthController(UserDAO userDAO, JwtUtil jwtUtil, PasswordEncoder passwordEncoder) {
        this.userDAO = userDAO;
        this.jwtUtil = jwtUtil;
        this.passwordEncoder = passwordEncoder;
    }

    @PostMapping("/auth/login")
    public ResponseEntity<?> login(@RequestBody AuthRequest request, HttpServletResponse response) {
        System.out.println("Login attempt: Username=" + request.getUsername() + ", Password=" + request.getPassword());

        // Tìm người dùng trong database (Firebase)
        User user = userDAO.findByUsername(request.getUsername());
        System.out.println(user.getRole());

        // Kiểm tra nếu người dùng không tồn tại
        if (user == null) {
            System.out.println("User not found: " + request.getUsername());
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Tên đăng nhập không tồn tại.");
        }

        // Kiểm tra mật khẩu
        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            System.out.println("Incorrect password for user: " + request.getUsername());
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Mật khẩu không đúng.");

        }

        // Tạo token JWT
        String token = jwtUtil.generateToken(user.getUsername(),user.getRole());
        System.out.println("Login successful for user: " + request.getUsername());

        // Lưu JWT vào cookie
        Cookie cookie = new Cookie("jwtToken", token);
        cookie.setHttpOnly(false);  // Không thể truy cập từ JavaScript
        cookie.setSecure(false);     // Chỉ gửi qua kết nối HTTPS
        cookie.setPath("/");        // Cookie có hiệu lực cho toàn bộ domain
        cookie.setMaxAge(18000);     // Hết hạn sau 1 giờ
        response.addCookie(cookie); // Thêm cookie vào response
        Cookie cookie1 = new Cookie("username", user.getUsername());
        cookie1.setHttpOnly(false);  // Không thể truy cập từ JavaScript
        cookie1.setSecure(false);     // Chỉ gửi qua kết nối HTTPS
        cookie1.setPath("/");        // Cookie có hiệu lực cho toàn bộ domain
        cookie1.setMaxAge(18000);     // Hết hạn sau 1 giờ
        response.addCookie(cookie1); // Thêm cookie vào response

        // Trả về token dưới dạng JSON thay vì chuỗi thông báo
        return ResponseEntity.ok(new AuthResponse(token));  // Trả về JSON chứa token
    }

}
