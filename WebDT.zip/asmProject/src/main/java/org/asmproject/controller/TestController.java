package org.asmproject.controller;

import io.jsonwebtoken.Claims;
import org.asmproject.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/test")
public class TestController {

    private final JwtUtil jwtUtil;

    @Autowired
    public TestController(JwtUtil jwtUtil) {
        this.jwtUtil = jwtUtil;
    }

    @GetMapping("/token")
    public String getTokenInfo(HttpServletRequest request) {
        // Lấy token từ cookie hoặc Authorization header
        String token = extractToken(request);

        // Log token để xem xét giá trị
        System.out.println("Token received: " + token);

        if (token != null && jwtUtil.validateToken(token)) {
            // Log nếu token hợp lệ
            System.out.println("Token is valid");

            Claims claims = jwtUtil.extractAllClaims(token);  // Dùng phương thức của JwtUtil để lấy tất cả các claims

            // Lấy thông tin từ claims
            String username = claims.getSubject();  // Giả sử subject là username
            String role = claims.get("role", String.class);  // Giả sử role là String

            // Log thông tin từ claims
            System.out.println("Username from claims: " + username);
            System.out.println("Role from claims: " + role);

            return String.format("Username: %s, Role: %s", username, role);
        } else {
            System.out.println("Invalid or missing token");
        }

        return "Invalid or missing token";
    }

    private String extractToken(HttpServletRequest request) {
        // Kiểm tra token từ cookie
        if (request.getCookies() != null) {
            for (Cookie cookie : request.getCookies()) {
                if ("jwtToken".equals(cookie.getName())) {
                    String cookieValue = cookie.getValue();
                    // Log giá trị token từ cookie
                    System.out.println("Token from cookie: " + cookieValue);
                    return cookieValue;
                }
            }
        }

        // Kiểm tra token từ Authorization header
        String bearer = request.getHeader("Authorization");
        if (bearer != null && bearer.startsWith("Bearer ")) {
            String token = bearer.substring(7);
            // Log giá trị token từ header
            System.out.println("Token from Authorization header: " + token);
            return token;
        }

        // Nếu không có token
        System.out.println("No token found in request");
        return null;
    }
}
