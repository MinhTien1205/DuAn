package org.asmproject.controller;

import org.asmproject.bean.Cart;
import org.asmproject.bean.CartProductDTO;
import org.asmproject.bean.Pay;
import org.asmproject.bean.Product;
import org.asmproject.dao.CartDAO;
import org.asmproject.dao.PayDAO;
import org.asmproject.dao.ProductDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/cart")
public class CartController {
    @Autowired
    private ProductDAO productDAO;
    @Autowired
    private CartDAO cartDAO;
    @Autowired
    private PayDAO payDAO;

    @PostMapping("/update")
    public String updateCart(@CookieValue(value = "username", defaultValue = "") String username,
                             @RequestParam String action) {

        System.out.println("🛒 [REST] action received: " + action);

        String[] parts = action.split("-", 2); // ✅ chỉ split 1 lần
        if (parts.length < 2) return "redirect:/cart/view";

        String type = parts[0];
        String productId = parts[1];

        Cart cart = cartDAO.getCartItem(username, productId);
        if (cart != null) {
            if ("increase".equals(type)) {
                cart.setQuantity(cart.getQuantity() + 1);
            } else if ("decrease".equals(type)) {
                if (cart.getQuantity() <= 1) {
                    cartDAO.removeFromCart(username, productId, cart.getId());
                } else {
                    cart.setQuantity(cart.getQuantity() - 1);
                    cartDAO.updateCart(cart);
                }
                return "redirect:/cart/view";
            }

            cartDAO.updateCart(cart);
        }

        return "redirect:/cart/view";
    }
    @GetMapping("/orders")
    public String viewOrders(Model model, @CookieValue(value = "username") String username) {
        // Fetch all payments and filter them by username
        List<Pay> userPayments = payDAO.getAllPaymentsWithKey().stream()
                .filter(pay -> pay.getUsername().equals(username))  // Filter by username
                .sorted((p1, p2) -> Long.compare(p2.getTimestamp(), p1.getTimestamp())) // Sort by timestamp (newest first)
                .collect(Collectors.toList());

        // Add the list of orders to the model
        model.addAttribute("orders", userPayments);
        model.addAttribute("page", "/cart/orders"); // Specify the view fragment
        return "layout"; // Return the main layout page
    }



    @GetMapping("/add")
    @ResponseBody
    public Map<String, Object> addToCart(@RequestParam String productId, @RequestParam String username) {
        if(username.isEmpty()||username.equals("null")) {
            Map<String, Object> res = new HashMap<>();
            res.put("status", "error");
            res.put("message", "Vui lòng đăng nhập để thêm sản phẩm vào giỏ hàng");
            return res; // ✅ trả về JSON luôn
        }
        System.out.println("🛒 [REST] Adding " + productId + " to " + username);

        Cart cart = new Cart(username, productId);
        cartDAO.addToCart(username, cart);

        Map<String, Object> res = new HashMap<>();
        res.put("status", "success");
        res.put("message", "Đã thêm sản phẩm vào giỏ hàng");
        return res; // ✅ trả về JSON luôn
    }

    @PostMapping("/remove")
    public String removeProduct(@RequestParam String productId, @RequestParam String username, @RequestParam String id) {
        // Logic to remove the product from the cart for the given username
        cartDAO.removeFromCart(username, productId, id);

        return "redirect:/cart/view";  // Redirect back to the cart page
    }


    @GetMapping("/view")
    public String viewCart(@CookieValue(value = "username", defaultValue = "") String username, Model model) {
        if (username.isEmpty()) {
            return "redirect:/account/login";
        }

        List<Cart> cartItems = cartDAO.getCartByUsername(username);
        Map<String, Product> allProducts = productDAO.findAllMap();
        List<CartProductDTO> cartProducts = new ArrayList<>();

        if (allProducts == null) {
            System.out.println("⚠️ Không lấy được danh sách sản phẩm từ Firebase!");
            model.addAttribute("cartProducts", cartProducts);
            model.addAttribute("page", "/cart/index");
            return "layout";
        }

        // Gộp sản phẩm theo productId (Firebase ID)
        Map<String, CartProductDTO> productMap = new HashMap<>();
        for (Cart cartItem : cartItems) {
            String productId = cartItem.getProductId();
            Product product = allProducts.get(productId);
            if (product == null) continue;

            if (productMap.containsKey(productId)) {
                CartProductDTO existing = productMap.get(productId);
                int newQuantity = existing.getCart().getQuantity() + cartItem.getQuantity();
                existing.getCart().setQuantity(newQuantity);
            } else {
                Cart newCart = new Cart(cartItem.getUsername(), productId);
                newCart.setQuantity(cartItem.getQuantity());
                productMap.put(productId, new CartProductDTO(newCart, product));
            }
        }

        // ✅ Gán danh sách trước khi tính tổng
        cartProducts = new ArrayList<>(productMap.values());
        model.addAttribute("cartProducts", cartProducts);

        double total = cartProducts.stream()
                .mapToDouble(item -> item.getProduct().getPrice() * item.getCart().getQuantity())
                .sum();
        model.addAttribute("cartTotal", total);

        model.addAttribute("page", "/cart/index");
        return "layout";
    }










}
