package org.asmproject.controller;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/info")
public class InfoController {

    @GetMapping("/about")
    public String index(Model model) {
        model.addAttribute("page","/info/gioithieu");
        return "layout";
    }
    @GetMapping("/contact")
    public String index1(Model model) {
        model.addAttribute("page","/info/lienhe");
        return "layout";
    }
}
