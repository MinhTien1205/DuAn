package org.asmproject.controller;

import com.fasterxml.jackson.core.JsonProcessingException;

import jakarta.servlet.http.HttpServletRequest;
import org.asmproject.bean.*;
import org.asmproject.dao.CartDAO;
import org.asmproject.dao.ProductDAO;
import org.asmproject.security.JwtUtil;
import org.asmproject.service.CartService;
import org.asmproject.service.PayService;
import org.asmproject.service.ProductService;
import org.asmproject.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/pay")
public class PayController {

    private final CartService cartService;
    private final PayService payService;
    private final UserService userService;
    private final JwtUtil jwtUtil;
    @Autowired
    private CartDAO cartDAO;
    @Autowired
    private ProductDAO productDAO;
    @Autowired
    public PayController(CartService cartService, PayService payService, UserService userService, JwtUtil jwtUtil) {
        this.cartService = cartService;
        this.payService = payService;
        this.userService = userService;
        this.jwtUtil = jwtUtil;
    }

    @GetMapping("/confirm")
    public String showCheckoutPage(Model model, HttpServletRequest request) {
        String username = jwtUtil.getUsernameFromToken(request);
        if (username == null) {
            return "redirect:/account/login";
        }

        User user = userService.findByUsername(username);

        model.addAttribute("user", user);

        List<Cart> cartItems = cartDAO.getCartByUsername(username);
        Map<String, Product> allProducts = productDAO.findAllMap();
        List<CartProductDTO> cartProducts = new ArrayList<>();

        if (allProducts == null) {
            System.out.println("⚠️ Không lấy được danh sách sản phẩm từ Firebase!");
            model.addAttribute("cartProducts", cartProducts);
            model.addAttribute("page", "/cart/index");
            return "layout";
        }

        // Gộp sản phẩm theo productId (Firebase ID)
        Map<String, CartProductDTO> productMap = new HashMap<>();
        for (Cart cartItem : cartItems) {
            String productId = cartItem.getProductId();
            Product product = allProducts.get(productId);
            if (product == null) continue;

            if (productMap.containsKey(productId)) {
                CartProductDTO existing = productMap.get(productId);
                int newQuantity = existing.getCart().getQuantity() + cartItem.getQuantity();
                existing.getCart().setQuantity(newQuantity);
            } else {
                Cart newCart = new Cart(cartItem.getUsername(), productId);
                newCart.setQuantity(cartItem.getQuantity());
                productMap.put(productId, new CartProductDTO(newCart, product));
            }
        }

        // ✅ Gán danh sách trước khi tính tổng
        cartProducts = new ArrayList<>(productMap.values());
        model.addAttribute("cartProducts", cartProducts);

        double total = cartProducts.stream()
                .mapToDouble(item -> item.getProduct().getPrice() * item.getCart().getQuantity())
                .sum();
        model.addAttribute("cartTotal", total);

        model.addAttribute("page", "/cart/request");
        return "layout";
    }



    @PostMapping("/checkout")
    public String checkout(@CookieValue("username") String username) throws JsonProcessingException {
        List<Cart> cartItems = cartDAO.getCartByUsername(username);
        Map<String, Product> allProducts = productDAO.findAllMap();

        List<CartProductDTO> cartProducts = new ArrayList<>();
        for (Cart cart : cartItems) {
            Product product = allProducts.get(cart.getProductId());
            if (product != null) {
                cartProducts.add(new CartProductDTO(cart, product));
            }
        }

        double total = cartProducts.stream()
                .mapToDouble(item -> item.getProduct().getPrice() * item.getCart().getQuantity())
                .sum();

        System.out.println("Tổng tiền: " + total);
        System.out.println("CartItems: " + cartItems);
        System.out.println("Username từ cookie: " + username);

        // Lưu thanh toán
        payService.processPayment(username, cartProducts, total);
        cartService.deleteCartAfterCheckout(username);
        return "redirect:/cart/view";
    }

}
