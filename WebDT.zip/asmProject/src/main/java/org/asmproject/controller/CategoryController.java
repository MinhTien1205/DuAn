package org.asmproject.controller;

import org.asmproject.bean.Category;
import org.asmproject.bean.CategoryMap;
import org.asmproject.dao.CategoryDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class CategoryController {

    @Autowired
    CategoryDAO dao;

    // Hiển thị danh sách các danh mục
    @RequestMapping("/category/index")
    public String index(Model model) {
        // Tạo một đối tượng Category với các thuộc tính mặc định
        Category category = new Category("", "");

        model.addAttribute("form", category);

        // Lấy danh sách danh mục từ DAO hoặc Repository
        CategoryMap items = dao.findAll();  // Giả sử dao trả về CategoryMap

        model.addAttribute("items", items);
        return "category/index";
    }

    // Chỉnh sửa danh mục theo ID
    @RequestMapping("/category/edit/{id}")
    public String edit(Model model, @PathVariable("id") String id) {
        model.addAttribute("id", id);
        Category category = dao.findByKey(id);
        model.addAttribute("form", category);
        CategoryMap map = dao.findAll();
        model.addAttribute("items", map);
        return "category/index";
    }

    // Tạo mới danh mục
    @RequestMapping("/category/create")
    public String create(Category category) {
        dao.create(category);
        return "redirect:/category/index";
    }

    // Cập nhật danh mục
    @RequestMapping("/category/update/{id}")
    public String update(@PathVariable("id") String id, Category category) {
        dao.update(id, category);
        return "redirect:/category/edit/" + id;
    }

    // Xóa danh mục
    @RequestMapping("/category/delete/{id}")
    public String delete(@PathVariable("id") String id) {
        dao.delete(id);
        return "redirect:/category/index";
    }
}
