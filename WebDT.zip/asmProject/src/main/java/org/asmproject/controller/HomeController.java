package org.asmproject.controller;

import org.asmproject.bean.Product;
import org.asmproject.bean.ProductPage;
import org.asmproject.service.ProductService;
import org.asmproject.bean.User;
import org.asmproject.service.UserService;
import org.asmproject.dao.ProductDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class HomeController {

    @Autowired
    ProductDAO dao;
    @Autowired
    ProductService productService;
    @Autowired
    UserService userService;

    @GetMapping("/getUser")
    public ResponseEntity<Map<String, Object>> getUserByToken(@CookieValue(name = "jwtToken", required = false) String token) {
        Map<String, Object> response = new HashMap<>();
        if (token != null && !token.isEmpty()) {
            User user = userService.findByJWT(token);
            if (user != null) {
                // Kiểm tra quyền admin
                boolean isAdmin = user.getRole().contains("ROLE_ADMIN");
                response.put("isAdmin", isAdmin); // Thêm isAdmin vào response
                response.put("username", user.getUsername());
                response.put("fullname", user.getFullname());
                return ResponseEntity.ok(response); // Trả về thông tin người dùng
            }
        }
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
    }



    @GetMapping("/product/{key}")
    public String viewProduct(Model model, @PathVariable("key") String key) {
        System.out.println(key+" Product is viewed");
        Product product = dao.findByKey(key);
        System.out.println(product);
        model.addAttribute("product", product);
        model.addAttribute("page", "/product/product");



        // Get 5 related products from the same category, excluding the current product
        List<Product> relatedProducts = dao.findAll().values().stream()
                .filter(p -> p.getCategory().equals(product.getCategory()) // Same category
                        && !p.getId().equals(product.getId())) // Exclude current product
                .limit(5) // Get only 5 products
                .toList();
        System.out.println(relatedProducts);
        model.addAttribute("relatedProducts", relatedProducts);

        return "layout";
    }

    @GetMapping("/find")
    public String findProducts(
            @RequestParam String name,
            @RequestParam(defaultValue = "0") Integer pageNumber,
            Model model) {

        String searchTerm = name.toLowerCase();
        int pageSize = 8;

        Pageable pageable = PageRequest.of(pageNumber, pageSize);
        Page<Product> productPage = productService.findProductsByNameContaining(searchTerm, pageable);

        model.addAttribute("items", productPage.getContent());
        model.addAttribute("searchTerm", name);
        model.addAttribute("page", "/product/find");
        model.addAttribute("pageNumber", pageNumber);
        model.addAttribute("totalPages", productPage.getTotalPages());

        return "layout";
    }


    @GetMapping({"/", "/page/{pageNumber}"})
    public String home(@PathVariable(required = false) Integer pageNumber,
                       @RequestParam(required = false) String category,
                       Model model) {

        int page = (pageNumber != null) ? pageNumber : 0;
        int pageSize = 8;

        ProductPage productPage;
        if (category != null && !category.isEmpty()) {
            productPage = productService.getProductsByCategory(page, pageSize, category);
            model.addAttribute("category", category);
        } else {
            productPage = productService.getPagedProducts(page, pageSize);
        }

        model.addAttribute("items", productPage.getContent());
        model.addAttribute("category", category); // vd: tb, dt, lp, pk
        model.addAttribute("page", "home");
        model.addAttribute("pageNumber", page);
        model.addAttribute("totalPages", productPage.getTotalPages());

        return "layout";
    }





}
