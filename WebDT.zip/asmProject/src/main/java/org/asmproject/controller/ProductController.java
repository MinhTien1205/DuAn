package org.asmproject.controller;

import jakarta.servlet.http.HttpServletRequest;
import org.asmproject.bean.CategoryMap;
import org.asmproject.bean.Product;
import org.asmproject.bean.ProductMap;
import org.asmproject.dao.LogDAO;
import org.asmproject.service.CategoryService;
import org.asmproject.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/product")
@EnableMethodSecurity
@PreAuthorize("hasAuthority('ROLE_ADMIN')")
public class ProductController {

    @Autowired
    private LogDAO logDAO;
    @Autowired
    private ProductService productService;

    @Autowired
    private CategoryService categoryService;

    // Trang index hiển thị danh sách sản phẩm

    @GetMapping("/index")
    public String index(@CookieValue(value = "username", required = false) String username,Model model, HttpServletRequest request) {

        // Tạo một đối tượng Product với các thuộc tính mặc định
        Product product = new Product("", "", 0.0, "", "", "VN");
        model.addAttribute("form", product);

        // Lấy danh mục và sản phẩm
        CategoryMap categories = categoryService.getAllCategories();
        model.addAttribute("cat", categories.values());

        ProductMap products = productService.getAllProducts();
        model.addAttribute("items", products);
        model.addAttribute("page", "/product/index");
        return "layout";
    }


    // Thêm sản phẩm mới
    @PostMapping("/create")
    public String create(@CookieValue("username") String username , Product product) {
        productService.createProduct(product);
        System.out.println("Username: " + username+" is create product: "+product.getName());
        logDAO.saveLog(username,"Action create: "+product.getName());

        return "redirect:/product/index";
    }

    // Sửa sản phẩm
    @GetMapping("/edit/{key}")
    public String edit(@CookieValue(value = "username", required = false) String username, Model model, @PathVariable("key") String key) {
        model.addAttribute("key", key);

        // Lấy sản phẩm theo key từ ProductService
        Product product = productService.getProductByKey(key);
        model.addAttribute("form", product);

        // Lấy tất cả sản phẩm từ ProductService
        ProductMap products = productService.getAllProducts();
        model.addAttribute("items", products);

        // Lấy tất cả danh mục từ CategoryService
        CategoryMap categories = categoryService.getAllCategories();
        model.addAttribute("cat", categories.values());
        System.out.println("Username: " + username+" is editing product: "+product.getName());
        logDAO.saveLog(username,"Action editing: "+product.getName());

        model.addAttribute("page", "/product/index");
        return "layout";
    }

    // Cập nhật sản phẩm
    @PostMapping("/update/{key}")
    public String update(@CookieValue("username") String username, @PathVariable("key") String key, Product product) {
        System.out.println("Username: " + username+" is update product: "+product.getName());
        logDAO.saveLog(username,"Action update:"+product.getName());
        productService.updateProduct(key, product);

        return "redirect:/product/index";
    }

    // Xóa sản phẩm
    @PostMapping("/delete/{key}")
    public String delete(@CookieValue("username") String username, @PathVariable("key") String key) {
        // Lấy sản phẩm theo key từ ProductService
        Product product = productService.getProductByKey(key);
        System.out.println("Username: " + username+" is delete product: "+product.getName());
        logDAO.saveLog(username,"Action delete: "+product.getName());
        productService.deleteProduct(key);
        return "redirect:/product/index";
    }
}
