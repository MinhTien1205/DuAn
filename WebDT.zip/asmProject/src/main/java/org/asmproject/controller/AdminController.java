package org.asmproject.controller;

import jakarta.servlet.http.HttpServletRequest;
import org.asmproject.bean.*;
import org.asmproject.dao.LogDAO;
import org.asmproject.dao.PayDAO;
import org.asmproject.service.CategoryService;
import org.asmproject.service.ProductService;
import org.asmproject.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private ProductService productService;
    @Autowired
    private UserService userService;
    @Autowired
    private CategoryService categoryService;
    @Autowired
    private LogDAO logDAO;
    @Autowired
    private PayDAO payDAO;

    // Dashboard - View the total number of orders and revenue
    @GetMapping
    public String adminDashboard(Model model) {
        // Orders and Revenue
        List<Pay> allOrders = payDAO.getAllPaymentsWithKey();
        long totalOrders = allOrders.size();
        double totalRevenue = allOrders.stream()
                .mapToDouble(Pay::getTotal)
                .sum();

        // Ensure orders have valid users
        for (Pay order : allOrders) {
            if (order.getUser() == null) {
                order.setUser(new User()); // You can set a default user or handle the situation appropriately
                System.out.println(order.getUser());
            }
        }

        // Recent Orders (last 5)
        List<Pay> recentOrders = allOrders.stream()
                .sorted((p1, p2) -> Long.compare(p2.getTimestamp(), p1.getTimestamp()))
                .limit(5)
                .toList();

        // Products by Category
        List<Product> products = productService.getAllProductsWithKey();
        Map<String, Long> categoryStats = products.stream()
                .collect(Collectors.groupingBy(
                        Product::getCategory,
                        Collectors.counting()
                ));

        model.addAttribute("totalOrders", totalOrders);
        model.addAttribute("totalRevenue", totalRevenue);
        model.addAttribute("recentOrders", recentOrders);
        model.addAttribute("products", products);
        model.addAttribute("categoryStats", categoryStats);
        model.addAttribute("page", "/admin/dashboard");
        return "layout";
    }

    @GetMapping("/product/index")
    public String index(@CookieValue(value = "username", required = false) String username,Model model, HttpServletRequest request) {

        // Tạo một đối tượng Product với các thuộc tính mặc định
        Product product = new Product("", "", 0.0, "", "", "VN");
        model.addAttribute("form", product);

        // Lấy danh mục và sản phẩm
        CategoryMap categories = categoryService.getAllCategories();
        model.addAttribute("cat", categories.values());

        ProductMap products = productService.getAllProducts();
        model.addAttribute("items", products);
        model.addAttribute("page", "/product/index");
        return "layout";
    }
    // Manage Products - View all products
    @GetMapping("/products")
    public String manageProducts(Model model) {
        List<Product> products = new ArrayList<>(productService.getAllProducts().values());

        model.addAttribute("products", products);
        model.addAttribute("page", "/admin/products");
        return "layout";
    }
    // Sửa sản phẩm
    @GetMapping("/product/edit/{key}")
    public String edit(@CookieValue(value = "username", required = false) String username, Model model, @PathVariable("key") String key) {
        model.addAttribute("key", key);

        // Lấy sản phẩm theo key từ ProductService
        Product product = productService.getProductByKey(key);
        model.addAttribute("form", product);

        // Lấy tất cả sản phẩm từ ProductService
        ProductMap products = productService.getAllProducts();
        model.addAttribute("items", products);

        // Lấy tất cả danh mục từ CategoryService
        CategoryMap categories = categoryService.getAllCategories();
        model.addAttribute("cat", categories.values());
        System.out.println("Username: " + username+" is editing product: "+product.getName());
        logDAO.saveLog(username,"Action editing: "+product.getName());

        model.addAttribute("page", "/product/index");
        return "layout";
    }


    // Thêm sản phẩm mới
    @PostMapping("/product/create")
    public String create(@CookieValue("username") String username , Product product) {
        productService.createProduct(product);
        System.out.println("Username: " + username+" is create product: "+product.getName());
        logDAO.saveLog(username,"Action create: "+product.getName());

        return "redirect:/product/index";
    }

    // Delete Product - Delete a specific product by ID
    @GetMapping("/product/delete/{id}")
    public String deleteProduct(@PathVariable String id) {
        productService.deleteProduct(id);
        return "redirect:/admin/products";
    }

    // Manage Orders - View all orders
    @GetMapping("/orders")
    public String manageOrders(Model model) {
        List<Pay> orders = payDAO.getAllPaymentsWithKey();

        // Gán thêm thông tin user vào từng đơn hàng nếu cần
        for (Pay order : orders) {
            String userId = order.getUsername();
            if (userId != null) {
                User user = userService.findById(userId); // hoặc findByUsername nếu userId là username
                order.setUser(user); // cần thêm field `User user` trong class `Pay`
            }
        }

        model.addAttribute("orders", orders);
        model.addAttribute("page", "/admin/orders");
        return "layout";
    }


//    @GetMapping("/orders")
//    public String manageOrders(@RequestParam(required = false) String status, Model model) {
//        List<Pay> orders = payDAO.getAllPaymentsWithKey();
//
//        if (status != null && !status.equals("all")) {
//            orders = orders.stream()
//                    .filter(order -> order.getStatus().equals(status))
//                    .collect(Collectors.toList());
//        }
//
//        model.addAttribute("orders", orders);
//        model.addAttribute("page", "/admin/orders");
//        return "layout";
//    }

    @PostMapping("/orders/{id}/status")
    @ResponseBody
    public ResponseEntity<String> updateOrderStatus(@PathVariable String id, @RequestBody Map<String, String> status) {
        Pay order = payDAO.getPaymentById(id);
        if (order != null) {
            order.setStatus(status.get("status"));
            payDAO.updatePayment(order.getId(), order.getStatus());
            return ResponseEntity.ok("Status updated successfully");
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/orders/{id}/details")
    public String orderDetails(
            @PathVariable String id,
            @CookieValue(value = "username", defaultValue = "") String username,
            Model model) {
        try {
            // Kiểm tra đăng nhập
            if (username.isEmpty()) {
                return "redirect:/account/login";
            }

            // Lấy đơn hàng từ Firebase
            Pay order = payDAO.getPaymentById(id);
            if (order == null) {
                return "redirect:/admin/orders";
            }

            // Lấy thông tin người dùng từ cookie thay vì từ order
           User user = userService.findByUsername(order.getUsername());
            System.out.println(user);
//            if (user == null) {
//                user = new User(); // Tránh null pointer
//            }

            // Lấy chi tiết sản phẩm và cập nhật lại product trong DTO
            List<CartProductDTO> items = new ArrayList<>();
            if (order.getItems() != null) {
                for (CartProductDTO item : order.getItems()) {
                    Product product = productService.getProductById(item.getProduct().getId());
                    if (product != null) {
                        item.setProduct(product);
                        items.add(item);
                    }
                }
            }

            // Gán lại thông tin vào order
            order.setUser(user);
            order.setItems(items);

            model.addAttribute("order", order);
            model.addAttribute("page", "/admin/order-details");
            return "layout";

        } catch (Exception e) {
            e.printStackTrace();
            return "redirect:/admin/orders";
        }
    }

    @GetMapping("/users")
    public String adminUsers(Model model) {
        List<User> users = userService.findAllUsers();

        model.addAttribute("users", users);
        model.addAttribute("page", "/admin/users");
        return "layout";
    }

}
