package org.asmproject.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.asmproject.bean.LogEntry;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.client.RestTemplate;

import java.util.*;
import java.util.stream.Collectors;

@Controller
public class LogController {

    private final String url = "https://poly-java-6-7593b-default-rtdb.firebaseio.com/logs.json";
    private final RestTemplate rest = new RestTemplate();

    @GetMapping("/logs")
    public String viewLogs(Model model) {
        JsonNode response = rest.getForObject(url, JsonNode.class);
        List<LogEntry> logs = new ArrayList<>();
        ObjectMapper mapper = new ObjectMapper();

        if (response != null && response.isObject()) {
            response.fields().forEachRemaining(entry -> {
                try {
                    LogEntry log = mapper.treeToValue(entry.getValue(), LogEntry.class);
                    logs.add(log);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
        }

        // Lọc duy nhất theo cặp (username, message), giữ lại log mới nhất theo timestamp
        Map<String, LogEntry> uniqueLogsMap = logs.stream()
                .collect(Collectors.toMap(
                        log -> log.getUsername() + "::" + log.getMessage(),
                        log -> log,
                        (log1, log2) -> log1.getTimestamp().after(log2.getTimestamp()) ? log1 : log2,
                        LinkedHashMap::new // preserve insertion order
                ));

        List<LogEntry> uniqueLogs = new ArrayList<>(uniqueLogsMap.values());

        // Sắp xếp theo timestamp mới nhất
        uniqueLogs.sort(Comparator.comparing(LogEntry::getTimestamp).reversed());

        // Lấy danh sách người dùng duy nhất
        Set<String> uniqueUsernames = uniqueLogs.stream()
                .map(LogEntry::getUsername)
                .collect(Collectors.toCollection(LinkedHashSet::new)); // preserve order

        model.addAttribute("usernames", uniqueUsernames);
        model.addAttribute("logs", uniqueLogs);

        return "/admin/log/log"; // Tên file HTML
    }

}
