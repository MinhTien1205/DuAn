package org.asmproject.controller;

import lombok.RequiredArgsConstructor;
import org.asmproject.bean.Product;
import org.asmproject.dao.ProductDAO;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequiredArgsConstructor
public class ProductUtilityController {

    private final ProductDAO dao;

    // Endpoint để set id = key cho tất cả sản phẩm
    @GetMapping("/admin/fix-product-ids")
    public String fixProductIds() {
        Map<String, Product> all = dao.findAllMap();

        int count = 0;
        for (Map.Entry<String, Product> entry : all.entrySet()) {
            String key = entry.getKey();
            Product product = entry.getValue();
            product.setId(key); // Gán id = key
            dao.update(key, product); // Ghi đè lại Firebase
            count++;
        }

        return "Đã cập nhật ID cho " + count + " sản phẩm.";
    }
}
