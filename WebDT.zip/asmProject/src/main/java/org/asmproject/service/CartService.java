package org.asmproject.service;

import org.asmproject.bean.Cart;
import org.asmproject.dao.CartDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CartService {

    private final CartDAO cartDAO;

    @Autowired
    public CartService(CartDAO cartDAO) {
        this.cartDAO = cartDAO;
    }

    public List<Cart> getUserCart(String username) {
        return cartDAO.getCartByUsername(username);
    }

    public void deleteCartAfterCheckout(String username) {
        List<Cart> carts = cartDAO.getCartByUsername(username);
        for (Cart cart : carts) {
            cartDAO.removeFromCart(username, cart.getProductId(), cart.getId());
        }
        System.out.println("🧹 Đã xóa toàn bộ giỏ hàng của người dùng: " + username);
    }
}

