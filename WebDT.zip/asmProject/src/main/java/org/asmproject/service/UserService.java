package org.asmproject.service;

import org.asmproject.bean.User;
import org.asmproject.bean.UserMap;
import org.asmproject.dao.UserDAO;
import org.asmproject.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class UserService {

    private final UserDAO userDAO;
    private final JwtUtil jwtUtil;

    @Autowired
    public UserService(UserDAO userDAO, JwtUtil jwtUtil) {
        this.userDAO = userDAO;
        this.jwtUtil = jwtUtil;
    }

    public List<User> findAllUsers() {
        UserMap userMap = userDAO.findAll();
        return new ArrayList<>(userMap.values());
    }

    public User findUserByKey(String key) {
        return userDAO.findByKey(key);
    }

    public User findByUsername(String username) {
        return userDAO.findByUsername(username);
    }

    public User findByJWT(String jwt) {
        return userDAO.findByUsername(jwtUtil.extractUsername(jwt));
    }

    public boolean isUserExists(String username) {
        return userDAO.findByUsername(username) != null;
    }

    public String createUser(User user) {
        return userDAO.create(user);
    }

    public User updateUser(String key, User user) {
        return userDAO.update(key, user);
    }

    public void deleteUser(String key) {
        userDAO.delete(key);
    }

    public User findById(String id) {
        return findUserByKey(id);
    }

}
