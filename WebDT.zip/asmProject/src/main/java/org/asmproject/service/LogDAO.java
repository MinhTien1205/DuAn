package org.asmproject.dao;

import com.fasterxml.jackson.databind.JsonNode;
import org.asmproject.bean.LogEntry;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;

import java.util.Date;

@Repository
public class LogDAO {

    private final RestTemplate rest = new RestTemplate();
    private final String url = "https://poly-java-6-7593b-default-rtdb.firebaseio.com/logs.json";

    public String saveLog(String username, String message) {
        LogEntry entry = new LogEntry(message, username, new Date());
        HttpEntity<LogEntry> entity = new HttpEntity<>(entry);
        JsonNode response = rest.postForObject(url, entity, JsonNode.class);
        return response != null && response.has("name") ? response.get("name").asText() : null;
    }
}
