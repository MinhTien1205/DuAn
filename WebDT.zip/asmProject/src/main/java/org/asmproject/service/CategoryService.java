package org.asmproject.service;

import org.asmproject.bean.Category;
import org.asmproject.bean.CategoryMap;
import org.asmproject.dao.CategoryDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CategoryService {

    @Autowired
    private CategoryDAO categoryDAO;

    // Lấy tất cả danh mục
    public CategoryMap getAllCategories() {
        return categoryDAO.findAll();
    }

    // Lấy danh mục theo key
    public Category getCategoryByKey(String key) {
        return categoryDAO.findByKey(key);
    }

    // Tạo mới danh mục
    public String createCategory(Category category) {
        return categoryDAO.create(category);
    }

    // Cập nhật danh mục
    public Category updateCategory(String key, Category category) {
        return categoryDAO.update(key, category);
    }

    // Xóa danh mục
    public void deleteCategory(String key) {
        categoryDAO.delete(key);
    }
}
