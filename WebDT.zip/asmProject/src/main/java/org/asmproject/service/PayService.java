package org.asmproject.service;

import org.asmproject.bean.CartProductDTO;
import org.asmproject.bean.Pay;
import org.asmproject.dao.PayDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PayService {

    private final PayDAO payDAO;

    @Autowired
    public PayService(PayDAO payDAO) {
        this.payDAO = payDAO;
    }

    public void processPayment(String username, List<CartProductDTO> cartItems, double total) {
        Pay pay = new Pay(username, cartItems, total);
        payDAO.create(pay);
    }
}
