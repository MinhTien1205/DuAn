package org.asmproject.service;

import org.asmproject.bean.CategoryMap;
import org.asmproject.bean.Product;
import org.asmproject.bean.ProductMap;
import org.asmproject.bean.ProductPage;
import org.asmproject.dao.CategoryDAO;
import org.asmproject.dao.ProductDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class ProductService {

    @Autowired
    private ProductDAO productDAO;

    @Autowired
    private CategoryDAO categoryDAO;

    // Lấy tất cả sản phẩm
    public ProductMap getAllProducts() {
        return productDAO.findAll();
    }

    // Lấy sản phẩm theo key
    public Product getProductByKey(String key) {
        return productDAO.findByKey(key);
    }
    // Lấy sản phẩm theo id
    public Product getProductById(String id) {
        return productDAO.findById(id);
    }

    // Tạo mới sản phẩm
    public String createProduct(Product product) {
        return productDAO.create(product);
    }

    // Cập nhật sản phẩm
    public Product updateProduct(String key, Product product) {
        return productDAO.update(key, product);
    }

    // Xóa sản phẩm
    public void deleteProduct(String key) {
        productDAO.delete(key);
    }

    // Lấy tất cả danh mục
    public CategoryMap getAllCategories() {
        return categoryDAO.findAll();
    }

    // Lấy tất cả sản phẩm từ Firebase có set id
    public List<Product> getAllProductsWithKey() {
        Map<String, Product> productMap = productDAO.findAllMap();
        return productMap.entrySet().stream()
                .map(entry -> {
                    Product product = entry.getValue();
                    product.setId(entry.getKey());
                    return product;
                }).collect(Collectors.toList());
    }

    // Lấy sản phẩm theo trang (không phân loại)
    public List<Product> getProductsByPage(int page, int size) {
        List<Product> products = getAllProductsWithKey();

        int fromIndex = page * size;
        int toIndex = Math.min(fromIndex + size, products.size());

        if (fromIndex >= products.size()) return Collections.emptyList();

        return products.subList(fromIndex, toIndex);
    }

    // Đếm tổng số sản phẩm
    public int getTotalProductCount() {
        return getAllProductsWithKey().size();
    }

    // Trả về trang sản phẩm (dạng có phân trang)
    public ProductPage getPagedProducts(int page, int pageSize) {
        List<Product> allProducts = getAllProductsWithKey();
        int totalPages = (int) Math.ceil((double) allProducts.size() / pageSize);

        int start = page * pageSize;
        int end = Math.min(start + pageSize, allProducts.size());

        List<Product> pageItems = (start < allProducts.size()) ? allProducts.subList(start, end) : Collections.emptyList();

        return new ProductPage(pageItems, totalPages);
    }

    // Trả về sản phẩm theo danh mục + phân trang
    public ProductPage getProductsByCategory(int page, int size, String category) {
        List<Product> allProducts = getAllProductsWithKey();
        List<Product> filtered = allProducts.stream()
                .filter(p -> p.getCategory() != null && p.getCategory().equalsIgnoreCase(category))
                .collect(Collectors.toList());

        int totalPages = (int) Math.ceil((double) filtered.size() / size);
        int fromIndex = page * size;
        int toIndex = Math.min(fromIndex + size, filtered.size());

        List<Product> pageContent = (fromIndex < filtered.size())
                ? filtered.subList(fromIndex, toIndex)
                : Collections.emptyList();

        return new ProductPage(pageContent, totalPages);
    }

    public Page<Product> findProductsByNameContaining(String searchTerm, Pageable pageable) {
        List<Product> allProducts = getAllProductsWithKey();

        List<Product> filtered = allProducts.stream()
                .filter(p -> p.getName() != null && p.getName().toLowerCase().contains(searchTerm.toLowerCase()))
                .collect(Collectors.toList());

        int total = filtered.size();
        int start = (int) pageable.getOffset();
        int end = Math.min((start + pageable.getPageSize()), total);

        List<Product> pageContent = (start < total)
                ? filtered.subList(start, end)
                : Collections.emptyList();

        return new PageImpl<>(pageContent, pageable, total);
    }


}
