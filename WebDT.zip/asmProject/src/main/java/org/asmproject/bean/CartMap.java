package org.asmproject.bean;

import java.util.HashMap;

public class CartMap extends HashMap<String, Cart> {
}
