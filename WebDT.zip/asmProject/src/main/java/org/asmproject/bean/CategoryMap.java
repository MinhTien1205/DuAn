package org.asmproject.bean;

import java.util.HashMap;

public class CategoryMap extends HashMap<String, Category> {
}
