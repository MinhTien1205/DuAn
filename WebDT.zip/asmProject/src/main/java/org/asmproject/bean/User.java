package org.asmproject.bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {
    private String username;
    private String password;
    private String role = "ROLE_USER"; // Mặc định là USER
    private String email;
    private String phone;
    private String address;
    private String fullname;

}
