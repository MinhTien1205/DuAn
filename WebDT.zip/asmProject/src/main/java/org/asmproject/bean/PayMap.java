package org.asmproject.bean;

import lombok.Data;

import java.util.HashMap;
import java.util.Map;

@Data
public class PayMap extends HashMap<String, Pay> {
    // Lớp này kế thừa từ HashMap để có thể sử dụng như một Map<String, Pay>
    // Có thể thêm các phương thức tùy chỉnh nếu cần
}

