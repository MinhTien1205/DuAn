package org.asmproject.bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Pay {
    private String id; // Firebase key
    private String username;
    private User user;
    private List<CartProductDTO> items;
    private double total;
    private long timestamp;
    private String status = "pending"; // "pending", "completed", etc.

    public Pay(String username, List<CartProductDTO> items, double total) {
        this.username = username;
        this.items = items;
        this.total = total;
        this.timestamp = System.currentTimeMillis();
    }
}
