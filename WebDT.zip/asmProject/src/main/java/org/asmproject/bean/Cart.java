package org.asmproject.bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Cart {
    private String id; // Firebase key
    private String username;
    private String productId;
    private int quantity;

    public Cart(String username, String productId) {
        this.username = username;
        this.productId = productId;
        this.quantity = 1;
    }
}

