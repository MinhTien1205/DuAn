package org.asmproject.bean;

import lombok.Data;

import java.util.List;
@Data
public class ProductPage {
    private List<Product> content;
    private int totalPages;

    public ProductPage(List<Product> content, int totalPages) {
        this.content = content;
        this.totalPages = totalPages;
    }

}

