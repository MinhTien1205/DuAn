package org.asmproject.bean;

import java.util.HashMap;

public class UserMap extends HashMap<String, User> {
}
