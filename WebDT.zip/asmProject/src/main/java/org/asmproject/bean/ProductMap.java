package org.asmproject.bean;

import lombok.Data;

import java.util.HashMap;
import java.util.Map;

@Data
public class ProductMap extends HashMap<String, Product> {

}

