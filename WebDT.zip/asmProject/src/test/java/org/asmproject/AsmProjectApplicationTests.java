package org.asmproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AsmProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
